﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ValidationFramework.GUI.Validators
{
    public interface IValidator
    {        
        event EventHandler Validated;
        bool IsValid { get; }
        bool Validate();
    }

    public abstract class Validator : IValidator
    {
        public event EventHandler Validated;

        protected ValueProvider value;
        public Validator(ValueProvider value)
        {
            this.value = value;
        }
        
        public bool IsValid { get; private set; }

        protected abstract bool ValidateResult();
        public bool Validate()
        {
            IsValid = ValidateResult();
            Validated?.Invoke(this, EventArgs.Empty);
            return IsValid;
        }
    }

}
