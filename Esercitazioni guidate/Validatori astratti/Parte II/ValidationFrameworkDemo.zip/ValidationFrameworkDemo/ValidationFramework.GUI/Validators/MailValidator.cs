﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ValidationFramework.GUI.Validators
{
    public class MailValidator: Validator
    {
        public MailValidator(ValueProvider value):base(value)
        {            
        }

        char[] sep = { '@' };

        protected override bool ValidateResult()
        {
            string[] items = value().Split(sep, StringSplitOptions.RemoveEmptyEntries);
            return items.Length == 2;
        }

    }
}
