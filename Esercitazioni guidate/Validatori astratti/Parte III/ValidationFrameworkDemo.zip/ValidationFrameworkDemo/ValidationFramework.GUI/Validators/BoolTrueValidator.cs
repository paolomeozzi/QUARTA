﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ValidationFramework.GUI.Validators
{
    class BoolTrueValidator : ValueValidator
    {
        public BoolTrueValidator(ValueProvider value):base(value)
        {

        }

        protected override bool ValidateResult()
        {
            return value() == "True";
        }
    }
}
