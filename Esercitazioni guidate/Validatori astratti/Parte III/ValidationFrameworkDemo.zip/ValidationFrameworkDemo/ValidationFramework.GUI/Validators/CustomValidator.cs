﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ValidationFramework.GUI.Validators
{
    class CustomValidator : Validator
    {
        Func<bool> validationLogic;
        public CustomValidator(Func<bool> validationLogic)
        {
            this.validationLogic = validationLogic;
        }

        protected override bool ValidateResult()
        {
            return validationLogic();
        }
        
    }
}
