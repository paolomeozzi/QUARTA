﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ValidationFramework.GUI.Validators
{
    public class DateValidator: ValueValidator
    {
        
        public DateValidator(ValueProvider value):base(value)
        {
        }
        protected override bool ValidateResult()
        {
            return DateTime.TryParse(value(), out _);
        }
    }

    
}
