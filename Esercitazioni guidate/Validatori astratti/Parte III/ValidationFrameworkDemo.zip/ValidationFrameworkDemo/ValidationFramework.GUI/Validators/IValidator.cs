﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ValidationFramework.GUI.Validators
{
    public interface IValidator
    {        
        event EventHandler Validated;
        bool IsValid { get; }
        bool Validate();
    }

}
