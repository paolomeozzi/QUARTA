﻿using System;

namespace ValidationFramework.GUI.Validators
{
    public abstract class Validator : IValidator
    {
        
        public event EventHandler Validated;
        public bool IsValid { get; private set; }
        protected abstract bool ValidateResult();
        public bool Validate()
        {
            IsValid = ValidateResult();
            Validated?.Invoke(this, EventArgs.Empty);
            return IsValid;
        }
    }

    public abstract class ValueValidator : Validator
    {
        protected ValueProvider value;
        public ValueValidator(ValueProvider value)
        {
            this.value = value;
        }
    }

}